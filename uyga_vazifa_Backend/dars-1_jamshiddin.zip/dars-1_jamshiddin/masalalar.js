// // // 1-masala
var a;
console.log(typeof a);
var b = null;
console.log(typeof b);
console.log(typeof c);

// // // 2-masala

// console.log(typeof ({} = null));

// // 3-masala
console.log(false + null / 3);

// // 4-masal

console.log([] + {} - undefined * true);

// // 5-masala
let m = [] + 3n;
console.log(typeof b);

// 6-masala

let f = 5;
const n = 0;
var d = 13.6;

console.log(f / n == typeof d);

// 7-masala
// console.log(([] = (true / null) * undefined - n));

// 8-masala

console.log(typeof isNaN(Boolean) / null);
//  masala-9

let h = "hi";
var b = null;
const i = {};
console.log(typeof b - i * h);

// 9-masala
console.log(typeof n == {} && isNaN == []);

// 10-masala

console.log([] + (2 / a) * true ? "bravo" : 0);

// 11-masala
var k = !([] + {}) * null == 1;
console.log(k);

// 12-masala
console.log(typeof (3n == "NaN") / undefined);

// 13-masala
console.log((let = a % 3 == -1));

// 14-masala
console.log(typeof [string](fan) - -1);

// 15-masala

var j = 45;
console.log(typeof j[{}]);
